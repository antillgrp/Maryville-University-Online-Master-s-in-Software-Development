for time in range(1000):
    print("{:3}: I will never spam my friends again.".format(time))
